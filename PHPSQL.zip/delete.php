<?php
$cpf=$_POST['cpf'];

$servername="fdb28.awardspace.net";
$database= "3649129_bdaulaphp";
$username="3649129_bdaulaphp";
$password="1327nick";

$conn=mysqli_connect($servername,$username,$password,$database);
if(!$conn){
die("Não foi possivel estabelecer a conexão".mysqli_connect_error());
}
$cpf=$_POST['cpf'];
    $sql = ("DELETE FROM TesteTabelaPHP Where cpf='$cpf'");
if(mysqli_query($conn,$sql)) {
echo "Dados excluidos com sucesso";
}

else{
echo "Não foi possivel excluir os dados confira sua conexão   ERROR".$sql.mysqli_error($conn);}

mysqli_close($conn);
echo "<br></br><a href=\"index.html\">Clique pra voltar para home<a/>";
?>